let p1pos = com1pos = com2pos = com3pos = 0;
let p1check = com1check = com2check = com3check = 0;
let posincrement = 1694;

function carpos(){
if(car1.offsetLeft == 1536 && com1check == 0){
    com1check = 1;
    posincrement--;
    com1pos = posincrement;
    console.log(com1pos);
}
if(car2.offsetLeft == 1536 && com2check == 0){
    com2check = 1;
    posincrement--;
    com2pos = posincrement;
    console.log(com2pos);
}
if(car3.offsetLeft == 1536 && p1check == 0){
    p1check = 1;
    posincrement--;
    p1pos = posincrement;
    console.log(p1pos);
}
if(car4.offsetLeft == 1536 && com3check == 0){
    com3check = 1;
    posincrement--;
    com3pos = posincrement;
    console.log(com3pos);
}
}

function carposfinder(){
    if(com1check == 0){
    com1pos = car1.offsetLeft;
    }
    if(com2check == 0){
    com2pos = car2.offsetLeft;
    }
    if(p1check == 0){
    p1pos = car3.offsetLeft;
    }
    if(com3check == 0){
    com3pos = car4.offsetLeft;
}
}
