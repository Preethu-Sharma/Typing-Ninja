const typingText = document.querySelector(".typing-text p");
const inpField = document.querySelector(".input-field");
let wpmTag = document.querySelector(".speed span"); 
let tryAgainBtn = document.querySelector(".button1");
let mTimer = document.querySelector(".timer span");
let incorr = document.querySelector(".incorrectshow");
let car1 = document.querySelector(".road .car1");
let car2 = document.querySelector(".road .car2");
let car3 = document.querySelector(".road .car3");
let car4 = document.querySelector(".road .car4");
// cars which are in tables
let tb1 = document.querySelector(".tableresult .tb1");
let tb2 = document.querySelector(".tableresult .tb2");
let tb3 = document.querySelector(".tableresult .tb3");
let tb4 = document.querySelector(".tableresult .tb4");

// position and player in tables
let row1player = document.querySelector(".theight .row1player");
let row2player = document.querySelector(".theight .row2player");
let row3player = document.querySelector(".theight .row3player");
let row4player = document.querySelector(".theight .row4player");

let circle = document.querySelector(".circle");
let com1 = document.querySelector(".playerlane .com1");
let com2 = document.querySelector(".playerlane .com2");
let com3 = document.querySelector(".playerlane .com3");
let p1 = document.querySelector(".playerlane .p1");
let road1 = document.querySelector('.road .threestrips .road1');
let road2 = document.querySelector('.road .threestrips .road2');
let road3 = document.querySelector('.road .threestrips .road3');
let load = document.querySelector('.load');
let loadbackscreen = document.querySelector('.loadbackscreen');
let startline = document.querySelector('.startline');

// Table result reference
let okbtn = document.querySelector('.okbtn');
let tableresult = document.querySelector('.tableresult');

// canvas fireworks reference 
let canva = document.querySelector('#canvas');

// audio reference
let audio = document.createElement('audio');
audio.setAttribute('src','sounds/mostcut.mp3');
let audio2 = document.createElement('audio');
audio2.setAttribute('src','sounds/gameVoice.m4a');
let btnsound = document.createElement('audio');
btnsound.setAttribute('src','sounds/btnsound.mp3');
let go321 = document.createElement('audio');
go321.setAttribute('src','sounds/321go.m4a');
let carmovesound = document.createElement('audio');
carmovesound.setAttribute('src','sounds/Typerush carmove.m4a');
let forth_rank = document.createElement('audio');
forth_rank.setAttribute('src','sounds/Forth_Rank.m4a');
let first_cracker = document.createElement('audio');
first_cracker.setAttribute('src','sounds/First_cracker_sound.m4a');
let firecracker = document.createElement('audio');
firecracker.setAttribute('src','sounds/Fireworks2.m4a');

let clrtimer;
let charIndex = cpm = 0;
let countf = 0;
let count321 = 4;
let time = 0;
let mistake;
let finalchar;
let carstarter = 0;
let lanechanger = 0;
let carpercent = 0;
let carmovechanger = 0;
let tablecar1,tablecar2,tablecar3,tablecar4;
const cars = ["car1","car2","car3","car4","car5","car6","car7","car8","car9","car10","car11","car12","car13","car14","car15","car16","car17","car18","car19","car20","car21","car22","car23","car24","car25","car26","car27","car28","car29"];

function randomParagraph() {
    if(carstarter == 0){
        tryAgainBtn.style.display = "none";
        carmovesound.play();
        // lane changes here
        if(lanechanger == 0){
            com1.style.top = "4vh";
            car1.style.top = "3.3vh";
            com2.style.top = "19vh";
            car2.style.top = "18.2vh";
            p1.style.top = "34vh";
            car3.style.top = "33.7vh";
            com3.style.top = "49vh";
            car4.style.top = "48.1vh";
            lanechanger = 1;
        }
        else if(lanechanger == 1){
            com2.style.top = "4vh";
            car2.style.top = "3.3vh";
            com1.style.top = "19vh";
            car1.style.top = "18.2vh";
            com3.style.top = "34vh";
            car4.style.top = "33.7vh";
            p1.style.top = "49vh";
            car3.style.top = "48.1vh";
            lanechanger = 2;
        }
        else if(lanechanger == 2){
            com3.style.top = "4vh";
            car4.style.top = "3.3vh";
            com1.style.top = "19vh";
            car1.style.top = "18.2vh";
            com2.style.top = "34vh";
            car2.style.top = "33.7vh";
            p1.style.top = "49vh";
            car3.style.top = "48.1vh";
            lanechanger = 3;
        }
        else if(lanechanger == 3){
            com2.style.top = "4vh";
            car2.style.top = "3.3vh";
            p1.style.top = "19vh";
            car3.style.top = "18.2vh";
            com1.style.top = "34vh";
            car1.style.top = "33.7vh";
            com3.style.top = "49vh";
            car4.style.top = "48.1vh";
            lanechanger = 4;
        }
        else if(lanechanger == 4){
            p1.style.top = "4vh";
            car3.style.top = "3.3vh";
            com3.style.top = "19vh";
            car4.style.top = "18.2vh";
            com1.style.top = "34vh";
            car1.style.top = "33.7vh";
            com2.style.top = "49vh";
            car2.style.top = "48.1vh";
            lanechanger = 5;
        }
        else if(lanechanger == 5){
            com2.style.top = "4vh";
            car2.style.top = "3.3vh";
            com3.style.top = "19vh";
            car4.style.top = "18.2vh";
            p1.style.top = "34vh";
            car3.style.top = "33.7vh";
            com1.style.top = "49vh";
            car1.style.top = "48.1vh";
            lanechanger = 6;
        }
        else if(lanechanger == 6){
            com1.style.top = "4vh";
            car1.style.top = "3.3vh";
            com2.style.top = "19vh";
            car2.style.top = "18.2vh";
            com3.style.top = "34vh";
            car4.style.top = "33.7vh";
            p1.style.top = "49vh";
            car3.style.top = "48.1vh";
            lanechanger = 7;
        }
        else if(lanechanger == 7){
            p1.style.top = "4vh";
            car3.style.top = "3.3vh";
            com1.style.top = "19vh";
            car1.style.top = "18.2vh";
            com2.style.top = "34vh";
            car2.style.top = "33.7vh";
            com3.style.top = "49vh";
            car4.style.top = "48.1vh";
            lanechanger = 8;
        }
        else if(lanechanger == 8){
            com1.style.top = "4vh";
            car1.style.top = "3.3vh";
            p1.style.top = "19vh";
            car3.style.top = "18.2vh";
            com2.style.top = "34vh";
            car2.style.top = "33.7vh";
            com3.style.top = "49vh";
            car4.style.top = "48.1vh";
            lanechanger = 9;
        }
        else{
            com3.style.top = "4vh";
            car4.style.top = "3.3vh";
            com2.style.top = "19vh";
            car2.style.top = "18.2vh";
            p1.style.top = "34vh";
            car3.style.top = "33.7vh";
            com1.style.top = "49vh";
            car1.style.top = "48.1vh";
            lanechanger = 0;
        }

        // cars change here & tablecars takes reference from here
        let rIndex = Math.floor(Math.random() * cars.length);
        car1.src = `cars/${cars[rIndex]}.png`;
        tablecar1 = `cars/${cars[rIndex]}.png`;
        rIndex = Math.floor(Math.random() * cars.length);
        car2.src = `cars/${cars[rIndex]}.png`;
        tablecar2 = `cars/${cars[rIndex]}.png`;
        rIndex = Math.floor(Math.random() * cars.length);
        car3.src = `cars/${cars[rIndex]}.png`;
        tablecar3 = `cars/${cars[rIndex]}.png`;
        rIndex = Math.floor(Math.random() * cars.length);
        car4.src = `cars/${cars[rIndex]}.png`;
        tablecar4 = `cars/${cars[rIndex]}.png`;

        // cars display becoming block and cars coming on screen for first time
        car1.style.display = "block";
        car1.classList.add("carmove");
        car2.style.display = "block";
        car2.classList.add("carmove");
        car3.style.display = "block";
        car3.classList.add("carmove");
        car4.style.display = "block";
        car4.classList.add("carmove");
        setTimeout(() => {
            carstarter = 1;
            // first time when car comes that sound
            carmovesound.volume = 0.4;
            randomParagraph();
        }, 2700);
    }
    else{
    if(countf == 0){
        tryAgainBtn.style.display = "none";
        if(count321 > 0)
        {
        typingText.classList.add("count321");
        if(count321 == 4){ 
            // 3,2,1,go sound
            go321.play();

            // all p1,com1,com2,com3 display will be blocked 
        com1.style.display = "block";
        com2.style.display = "block";
        p1.style.display = "block";
        com3.style.display = "block";
        circle.style.backgroundColor = "red";  
        circle.style.display = "block";
        typingText.style.color = "white";
        typingText.innerHTML = count321 - 1;
        count321--;
        }
        else if(count321 == 3){    
        circle.style.display = "block";
        circle.style.backgroundColor = "yellow";  
        typingText.style.color = "black";
        typingText.innerHTML = count321 - 1;
        count321--;
        }
        else if(count321 == 2){   
        circle.style.display = "block"; 
        circle.style.backgroundColor = "green";  
        typingText.style.color = "white";
        typingText.innerHTML = count321 - 1;
        count321--;
        }
        else if(count321 == 1){    
        circle.style.display = "block";
        circle.style.backgroundColor = "green";  
        typingText.style.color = "white";
        typingText.innerHTML = "GO!";
        count321--;
        }
        setTimeout(randomParagraph,1000);
        }
        else{
            circle.style.backgroundColor = "white";  
            circle.style.display = "none";
            typingText.innerHTML = "";
            typingText.classList.remove("count321");
            typingText.style.color = "black";
            countf=1;
            count321 = 4;
            // audio2 starts from here
            audio2.play();
            audio2.loop = true;
            // car3 2nd class to move added here
            car3.classList.add("carmove2"); 

            // com1,com2,com3 car movement
            if(carmovechanger == 0){
                car1.classList.add("comcarmove1");
                car2.classList.add("comcarmove2");
                car4.classList.add("comcarmove3");
                carmovechanger = 1;
            }
            else if(carmovechanger == 1){
                car1.classList.add("comcarmove5");
                car2.classList.add("comcarmove6");
                car4.classList.add("comcarmove2");
                carmovechanger = 2;
            }
            else if(carmovechanger == 2){
                car1.classList.add("comcarmove10");
                car2.classList.add("comcarmove3");
                car4.classList.add("comcarmove5");
                carmovechanger = 3;
            }
            else if(carmovechanger == 3){
                car1.classList.add("comcarmove4");
                car2.classList.add("comcarmove9");
                car4.classList.add("comcarmove5");
                carmovechanger = 4;
            }
            else if(carmovechanger == 4){
                car1.classList.add("comcarmove12");
                car2.classList.add("comcarmove7");
                car4.classList.add("comcarmove8");
                carmovechanger = 5;
            }
            else if(carmovechanger == 5){
                car1.classList.add("comcarmove6");
                car2.classList.add("comcarmove4");
                car4.classList.add("comcarmove2");
                carmovechanger = 6;
            }
            else if(carmovechanger == 6){
                car1.classList.add("comcarmove11");
                car2.classList.add("comcarmove4");
                car4.classList.add("comcarmove5");
                carmovechanger = 7;
            }
            else if(carmovechanger == 7){
                car1.classList.add("comcarmove7");
                car2.classList.add("comcarmove1");
                car4.classList.add("comcarmove9");
                carmovechanger = 0;
            }


            // road 1,2,3 animation
            road1.style.animation = "road 400ms linear infinite";
            road2.style.animation = "road 400ms linear infinite";
            road3.style.animation = "road 400ms linear infinite";

            // startline animation
            startline.style.animation = "startlineleftmove 720ms linear";
            startline.style.animationFillMode = "forwards";

            // com1,com2,com3,p1 animation
            com1.style.animation = "com_mover 2.51s linear";
            com1.style.animationFillMode = "forwards";
            com2.style.animation = "com_mover 2.51s linear";
            com2.style.animationFillMode = "forwards";
            com3.style.animation = "com_mover 2.51s linear";
            com3.style.animationFillMode = "forwards";
            p1.style.animation = "p1_mover 2.51s linear";
            p1.style.animationFillMode = "forwards";
            randomParagraph();
        }  
    }
    else{
let randIndex = Math.floor(Math.random() * paragraphs.length);
typingText.innerHTML = "";
paragraphs[randIndex].split("").forEach( (span) =>{
    let spanTag = `<span>${span}</span>`;
    typingText.innerHTML = typingText.innerHTML + spanTag;
});
document.addEventListener("keydown",() => inpField.focus());
typingText.addEventListener("click",() => inpField.focus());
const characters = typingText.querySelectorAll("span");
characters[0].classList.add("active");
// tryAgainBtn.style.display = "block";
            if(time == 0){
                clrtimer = setInterval(initTimer,1000);
                time = 1;
            }
    }
}
}

function inittyping(event){
    if(event.data != null){
        finalchar = inpField.value;
    }
    if(countf == 1){
    const characters = typingText.querySelectorAll("span");
    let typedChar = inpField.value.split("")[charIndex];
    if(charIndex < characters.length -1){
        
            if(typedChar == null){
               if(mistake == 0){
                   inpField.value = finalchar.slice(0,finalchar.length);
               }
               else{
                inpField.value = finalchar.slice(0,finalchar.length - 1);
               }
               characters[charIndex].classList.remove("incorrect");
            }
            else{
                if(typedChar === characters[charIndex].innerText){
                    characters[charIndex].classList.remove("incorrect");
                    characters[charIndex].classList.add("correct");
                    mistake = 0;
                    cpm++;
                    charIndex++;
                }
                else{
                    characters[charIndex].classList.add("incorrect");
                    inpField.value = finalchar.slice(0,finalchar.length - 1);
                    mistake = 1;
                    audio.play();
                    incorr.style.display = "inline";
                    setTimeout(() => {
                        audio.pause();
                        audio.currentTime = 0;
                        incorr.style.display = "none";  
                    }, 500);
                    }    
            }
            characters.forEach((span) => {span.classList.remove("active")});
            characters[charIndex].classList.add("active");
            let wpm = Math.round(((cpm)  / 5) / ( time ) * 60);
            wpm = wpm < 0 || !wpm || wpm === Infinity ? 0 : wpm;
            wpmTag.innerText = wpm;
            carpercent = Math.ceil((charIndex / characters.length) * 100);
            carpos(); 
            // 1p car movement
            if(carpercent == 5){
                car3.classList.add("carmove3");
            }
            else if(carpercent == 8){
                car3.classList.add("carmove4");
            }
            else if(carpercent == 12){
                car3.classList.add("carmove5");
            }
            else if(carpercent == 16){
                car3.classList.add("carmove6");
            }
            else if(carpercent == 20){
                car3.classList.add("carmove7");
            }
            else if(carpercent == 23){
                car3.classList.add("carmove8");
            }
            else if(carpercent == 28){
                car3.classList.add("carmove9");
            }
            else if(carpercent == 35){
                car3.classList.add("carmove10");
            }
            else if(carpercent == 40){
                car3.classList.add("carmove11");
            }
            else if(carpercent == 55){
                car3.classList.add("carmove12"); 
            }
            else if(carpercent == 65){
                car3.classList.add("carmove13"); 
            }
            else if(carpercent == 72){
                car3.classList.add("carmove14");
            }
            else if(carpercent == 76){
                car3.classList.add("carmove15");
            }
            else if(carpercent == 80){
                car3.classList.add("carmove16"); 
            }
            else if(carpercent == 84){
                car3.classList.add("carmove17"); 
            }
            else if(carpercent == 88){
                car3.classList.add("carmove18");
            }
            else if(carpercent == 94){
                car3.classList.add("carmove19"); 
            }
            else if(carpercent == 100){
                car3.classList.add("carmove20");
            }
            
    }else{
        carpos();
        carposfinder();
        console.log(`com1pos is ${com1pos}`);
        console.log(`com2pos is ${com2pos}`);
        console.log(`p1pos is ${p1pos}`);
        console.log(`com3pos is ${com3pos}`);
        let playerint = [com1pos,com2pos,p1pos,com3pos];
        let playerstring = ["COM1","COM2","1p","COM3"];
        let tablecar = [tablecar1,tablecar2,tablecar3,tablecar4];

        for(let i=0; i<=2 ; i++){
            for(let j=0; j<=2 ; j++){
                if(playerint[j] > playerint[j+1]){
                    let temp = playerint[j+1];
                    playerint[j+1] = playerint[j];
                    playerint[j] = temp;
                    let temp2 = playerstring[j+1];
                    playerstring[j+1] = playerstring[j];
                    playerstring[j] = temp2;
                    let temp3 = tablecar[j+1];
                    tablecar[j+1] = tablecar[j];
                    tablecar[j] = temp3;
                }
            }
        }

        playerint[0] = 4;
        playerint[1] = 3;
        playerint[2] = 2;
        playerint[3] = 1;
        
        console.log(`${playerstring[3]} got ${playerint[3]}st position`);
        console.log(`${playerstring[2]} got ${playerint[2]}nd position`);
        console.log(`${playerstring[1]} got ${playerint[1]}rd  position`);
        console.log(`${playerstring[0]} got ${playerint[0]}th position`);

        // data added in table 
        row1player.innerHTML = `${playerstring[3]}`;
        row2player.innerHTML = `${playerstring[2]}`;
        row3player.innerHTML = `${playerstring[1]}`;
        row4player.innerHTML = `${playerstring[0]}`;

        // cars arranged in table
        tb4.src = tablecar[0];
        tb3.src = tablecar[1];
        tb2.src = tablecar[2];
        tb1.src = tablecar[3];

        setTimeout(() => {
            load.style.display = "block";
            loadbackscreen.style.display = "block";
            road1.style.animation = "";
            road2.style.animation = "";
            road3.style.animation = "";
            startline.style.animation = "";
            startline.style.left = "23.3vh";
            car1.classList.remove("carmove");
            car2.classList.remove("carmove");
            car3.classList.remove("carmove");
            car4.classList.remove("carmove");
            for(let i=2 ; i<=20 ; i++){
                car3.classList.remove(`carmove${i}`);
            }
            for(let j=1 ; j<=12 ; j++){
                car1.classList.remove(`comcarmove${j}`);
                car2.classList.remove(`comcarmove${j}`);
                car4.classList.remove(`comcarmove${j}`);
            }
            car1.style.left = "25vw";
            car2.style.left = "25vw";
            car3.style.left = "25vw";
            car4.style.left = "25vw";
            tableresult.style.display = "block";
        }, 4000);

        setTimeout(() => {
            load.style.display = "none";
            loadbackscreen.style.display = "none";

            const result = row4player.textContent;
            if(result == "1p"){
                forth_rank.play();
                forth_rank.loop = true;
               }
            else{
                canva.style.display = "block";
                first_cracker.play();
                setTimeout(() => {
                    firecracker.play();
                    firecracker.loop = true;
                }, 6000);
            }

        }, 8500);

        inpField.value = "";
        typingText.classList.add("gameover");
        typingText.style.color = "green"
        typingText.innerHTML = "Game Over";
        audio2.pause();
        audio2.currentTime = 0;
        audio2.loop = false;
        clearInterval(clrtimer);
    }
    }
}

function initTimer() {
  mTimer.innerHTML = time;
  time++;     
      carpos();
}

// OK button of result table
okbtn.addEventListener('click',()=>{
    tableresult.style.display = "none";
    tryAgainBtn.style.display = "block";
});

function resetGame(){
    // canvas display reset
    canva.style.display = "none";

    // Result table reset
    tableresult.style.display = "none";

    // for play again button
    tryAgainBtn.innerText = "Play Again";
    tryAgainBtn.style.display = "block";
    // 
    // for circle displaying 3,2,1,GO!
    circle.style.backgroundColor = "white";  
    circle.style.display = "none";
    // 
    // for removing display of com1,com2,com3,p1 
    com1.style.display = "none";
    com2.style.display = "none";
    p1.style.display = "none";
    com3.style.display = "none";
    // 
    // neutralizing p1,com1,com2,com3 animation moving towards left 
    com1.style.animation = "";
    com1.style.left = "40vw";
    com2.style.animation = "";
    com2.style.left = "40vw";
    com3.style.animation = "";
    com3.style.left = "40vw";
    p1.style.animation = "";
    p1.style.left = "42.5vw";
    // 
    // neutralizing road1,road2,road3 animation moving towards left
    road1.style.animation = "";
    road2.style.animation = "";
    road3.style.animation = "";
    // 
    // neutralizing startline animation moving towards left
    startline.style.animation = "";
    startline.style.left = "23.3vh";
    // 
    // button click sound audio
    btnsound.play();
    // incoorrect character wala audio
    audio.pause();
    audio.currentTime = 0;
    audio.volume = 1.0;
    // game starting wala audio
    audio2.pause();
    audio2.loop = false;
    audio2.currentTime = 0;
    audio2.volume = 0.7;
    // first time when car comes that sound
    carmovesound.pause();
    carmovesound.currentTime = 0;
    carmovesound.volume = 1.0;
    // 3,2,1,go sound reset
    go321.pause();
    go321.currentTime = 0;
    // first_cracker sound reset
    first_cracker.pause();
    first_cracker.currentTime = 0;
    // fireworks reset
    firecracker.pause();
    firecracker.loop = false;
    firecracker.currentTime = 0;
    // forth rank audio reset
    forth_rank.pause();
    forth_rank.loop = false;
    forth_rank.currentTime = 0; 

    // position reset
    p1pos = com1pos = com2pos = com3pos = 0;
    p1check = com1check = com2check = com3check = 0;
    posincrement = 1694;

    countf = 0;
    count321 = 4;
    charIndex = 0;
    mistake = undefined;
    cpm = 0;
    wpmTag.innerText = 0;
    mTimer.innerHTML = 0;
    time = 0;
    inpField.value = "";
    typingText.classList.remove("gameover");
    typingText.innerHTML = "";
    carstarter = 0;

    // After ending going back to first position assigned
    car1.style.left = "";
    car2.style.left = "";
    car3.style.left = "";
    car4.style.left = "";

    // car display remove and carmove class removed
    car1.style.display = "none";
    car1.classList.remove("carmove");
    car2.style.display = "none";
    car2.classList.remove("carmove");
    car3.style.display = "none";
    car3.classList.remove("carmove");
    car4.style.display = "none";
    car4.classList.remove("carmove");

    // classes which move p1 will be removed here
    for(let i=2 ; i<=20 ; i++){
        car3.classList.remove(`carmove${i}`);
    }
    // classes which move com1,com2,com3 will be removed here
    for(let j=1 ; j<=12 ; j++){
        car1.classList.remove(`comcarmove${j}`);
        car2.classList.remove(`comcarmove${j}`);
        car4.classList.remove(`comcarmove${j}`);
    }
    setTimeout(() => {
        randomParagraph();
    }, 100);
    clearInterval(clrtimer);
}


inpField.addEventListener("input",inittyping);
tryAgainBtn.addEventListener("click",resetGame);
